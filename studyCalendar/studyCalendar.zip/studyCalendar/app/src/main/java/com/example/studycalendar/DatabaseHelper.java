package com.example.studycalendar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static  final String TAG = "DatabaseHelper";

    private static  final String TABLE_NAME = "study_table";
    private static  final String ID = "id";
    private static  final String TITLE = "title";
    private static  final String DESCRIPTION = "description";
    private static  final String DATE = "start_date";



    public DatabaseHelper(Context context) {
        super(context, TABLE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createTable ="CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                +  TITLE + " text, "
                + DESCRIPTION + " text,"
                + DATE + " text)";

        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }

    boolean addData(StudyTable register){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DESCRIPTION,register.getDescription());
        contentValues.put(TITLE, register.getTitulo());
        contentValues.put(DATE,register.getDate().toString());

        Log.d(TAG, "addData: Adding" + register.toString() + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME,null,contentValues);

        return result != -1;

    }
    public Cursor getListContents(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM  " + TABLE_NAME, null);
        return data;

    }
}
