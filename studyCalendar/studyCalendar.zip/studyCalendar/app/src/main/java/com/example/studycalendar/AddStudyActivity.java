package com.example.studycalendar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class AddStudyActivity extends AppCompatActivity {

    DatabaseHelper mDatabaseHelper;
    Button btnAdd;
    private CalendarView calendarView;
    private EditText title, desripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_study);
        btnAdd  = (Button) findViewById(R.id.button);
        desripcion =(EditText)findViewById(R.id.informacionText);
        title = (EditText)findViewById(R.id.tituloText);
        calendarView = (CalendarView)findViewById(R.id.calendarSelect);
        mDatabaseHelper = new DatabaseHelper(this);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String descripcion = desripcion.getText().toString();

                if(descripcion.trim().equals("")){
                    toastMessage("Es necesario agreagar una descripcion");
                    return;
                }

                String titulo = title.getText().toString();

                if(titulo.trim().equals("")){
                    toastMessage("Es necesario agregar un titulo");
                    return;
                }
                long date = calendarView.getDate();

                StudyTable studyTable = new StudyTable();
                studyTable.setDate(new Date((date)));
                studyTable.setDescription(descripcion);
                studyTable.setTitulo(titulo);

                addData(studyTable);

                desripcion.setText("");
                title.setText("");

            }
        });
    }

    public void addData(StudyTable studyTable){
        boolean insertData = mDatabaseHelper.addData(studyTable);

        if(insertData){
            toastMessage("Los datos se registraron correctamente");
        }else {
            toastMessage("Ocurrio un error durante la ejecucion");

        }

    }

    private void toastMessage(String message){

        Toast.makeText(this, message ,Toast.LENGTH_SHORT).show();
    }
}
